class Password{
  //The first part of the class.
constructor(publickey, privatekey){
  this.publickey = publickey;
  this.privatekey = privatekey;
}
  //Instance functions below this comment.
  function validPublickey(){
    validPublicKey(){
     if(this.publickey.length >=8 && this.publickey.length <=25);
       return true
     }
     else{
      return false
    }

    validPrivateKey(){
     if(this.privatekey[4] == )"-" && this.privatekey[9] == "-");
       return true
         
  }


  //Static function below this comment.
}
