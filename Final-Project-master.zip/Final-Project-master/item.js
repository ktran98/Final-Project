class Item{
  //Fill in the item class below this comment
  constructor(name,price,shipping){
    this.name = name;
    this.price = price;
    this.shipping = shipping;
  };
}

//Create your three test items below this comment.
this.doll = new Item("Teddy",25,2);
this.game = new Item("Pokemon",30,3);
this.toy = new Item("Mini Car",15,1);
  
